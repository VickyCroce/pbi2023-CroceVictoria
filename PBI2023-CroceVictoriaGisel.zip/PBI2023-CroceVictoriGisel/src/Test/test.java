package Test;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import ar.edu.unlam.interfaz.*;

import org.junit.Test;

public class test {

	@Test
	public void queSePuedanAlmacenarLosDistintosTiposDeTransacciones() {
		Compra billetera = new Compra();
        CuentaBancaria cuentaBancaria = new CuentaBancaria("45454", 2.0);
        CuentasVirtuales cuentaVirtual = new CuentasVirtuales("55454", 10.0);
        TarjetaCredito tarjetaCredito = new TarjetaCredito("88879", 9.0);
        TarjetaDebito tarjetaDebito = new TarjetaDebito("448666", 500.0);

        billetera.registrarMedio(cuentaVirtual);
        billetera.registrarMedio(cuentaBancaria);
        billetera.registrarMedio(tarjetaCredito);
        billetera.registrarMedio(tarjetaDebito);
 
  
	}
	
	@Test
	public void queSePuedanAlmacenarLosDistintosTiposDePersonas() {
		Compra billetera = new Compra();
        PersonaJuridica persona1 = new PersonaJuridica("121212", "pepe");
        PersonaFisica persona2 = new PersonaFisica("5555", "juan");
        
        billetera.registrarPersona(persona1);
        billetera.registrarPersona(persona2);
        
	}
	
	@Test
	public void queSePuedanAsociarACadaPeronaSusMedios() {
		Compra billetera = new Compra();
		PersonaJuridica persona1 = new PersonaJuridica("121212", "pepe");
	    PersonaFisica persona2 = new PersonaFisica("5555", "juan");
        TarjetaDebito tarjetaDebito = new TarjetaDebito("448666", 500.0);
		Set<TarjetaDebito> mediosP1 = new HashSet<>();

		mediosP1.add(tarjetaDebito);
	
		
		billetera.registrarPersona(persona1);
	    billetera.registrarPersona(persona2);
        billetera.registrarMedio(tarjetaDebito);
		
		assertEquals(mediosP1, billetera.getMedios());
	}


}
