package ar.edu.unlam.interfaz;

public interface Medio {
	String getIdentificador();
	
}
