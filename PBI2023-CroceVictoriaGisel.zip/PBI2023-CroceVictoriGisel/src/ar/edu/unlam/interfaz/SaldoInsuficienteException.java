package ar.edu.unlam.interfaz;

public class SaldoInsuficienteException extends Exception {
	public SaldoInsuficienteException() {}
}
