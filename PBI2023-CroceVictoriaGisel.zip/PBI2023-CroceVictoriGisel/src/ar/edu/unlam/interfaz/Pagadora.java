package ar.edu.unlam.interfaz;

public interface Pagadora {
	Boolean pagar (Persona vendedor, Double importe) throws ExcedeLimiteDeCompraException;
}
