package ar.edu.unlam.interfaz;

import java.util.*;

public class Compra implements Billetera{
	private Map<String, Persona> personas;
    private Map<String, Medio> medios;

    public Compra() {
        this.personas = new HashMap<>();
        this.medios = new HashMap<>();
    }
    
    
	@Override
	public void registrarPersona(Persona persona) {
		// TODO Auto-generated method stub
		 personas.put(persona.getIdentificador(), persona);
	}

	@Override
	public void registrarMedio(Medio medio) {
		// TODO Auto-generated method stub
		 medios.put(medio.getIdentificador(), medio);
	}

	@Override
	public void realizarCompra(Persona vendedor, String codigoQR, Pagadora medioPagador)
			throws SaldoInsuficienteException, ExcedeLimiteDeCompraException {
				
	}

	@Override
	public void realizarTransferencia(Transferible origen, Transferible destino, double monto)
			throws SaldoInsuficienteException {
		// TODO Auto-generated method stub
		
	}

	public Map<String, Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(Map<String, Persona> personas) {
		this.personas = personas;
	}

	public Map<String, Medio> getMedios() {
		return medios;
	}

	public void setMedios(Map<String, Medio> medios) {
		this.medios = medios;
	}
	
    
}
