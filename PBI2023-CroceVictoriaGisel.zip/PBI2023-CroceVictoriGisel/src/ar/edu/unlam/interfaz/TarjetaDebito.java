package ar.edu.unlam.interfaz;

public class TarjetaDebito  implements Medio{
	private String numero;
	private double saldo;

	public TarjetaDebito(String numero,double saldo) {
		this.numero = numero;
		this.saldo = saldo;
	}


	@Override
	public String getIdentificador() {
		// TODO Auto-generated method stub
		return numero;
	}

	public void pagarConDebito(Double importe) throws SaldoInsuficienteException {
	if (getSaldo() < importe) {
        throw new SaldoInsuficienteException();
    }
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public double getSaldo() {
		return saldo;
	}


	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
}
