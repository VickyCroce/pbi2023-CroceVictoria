package ar.edu.unlam.interfaz;

public class TarjetaCredito implements Medio, Pagadora {
	private String numero;
	private double limiteDeCompra;

	public TarjetaCredito( String numero, double limiteDeCompra ) {
		this.numero = numero;
		this.limiteDeCompra = limiteDeCompra;
	}


	@Override
	public String getIdentificador() {
		// TODO Auto-generated method stub
		return numero;
	}


	@Override
	public Boolean pagar(Persona vendedor, Double importe) throws ExcedeLimiteDeCompraException {
		 if (getLimiteDeCompra() < importe) {
	            throw new ExcedeLimiteDeCompraException();
	        }
	        return true;
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public double getLimiteDeCompra() {
		return limiteDeCompra;
	}


	public void setLimiteDeCompra(double limiteDeCompra) {
		this.limiteDeCompra = limiteDeCompra;
	}

	
}
