package ar.edu.unlam.interfaz;

import java.util.Set;

public interface Persona {
	String getIdentificador();

}
