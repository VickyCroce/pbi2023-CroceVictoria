package ar.edu.unlam.interfaz;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class PersonaFisica implements Persona, Comparable<PersonaFisica> {
	private String nombre;
	private String cuil;
	List<Persona> personas;

	public PersonaFisica(String nombre, String cuil) {
		super();
		this.nombre = nombre;
		this.cuil = cuil;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCuil() {
		return cuil;
	}

	public void setCuil(String cuil) {
		this.cuil = cuil;
	}

	@Override
	public String getIdentificador() {
		// TODO Auto-generated method stub
		return cuil;
	}

	@Override
	public int compareTo(PersonaFisica otraPersona) {
		return this.cuil.compareTo(otraPersona.getIdentificador());
	}

}
