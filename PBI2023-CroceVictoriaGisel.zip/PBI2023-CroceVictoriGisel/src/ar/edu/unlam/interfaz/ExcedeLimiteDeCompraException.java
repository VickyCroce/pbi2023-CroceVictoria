package ar.edu.unlam.interfaz;

public class ExcedeLimiteDeCompraException extends Exception {
	public ExcedeLimiteDeCompraException() {}
}
