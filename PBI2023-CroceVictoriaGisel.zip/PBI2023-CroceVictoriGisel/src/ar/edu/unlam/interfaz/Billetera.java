package ar.edu.unlam.interfaz;

public interface Billetera {
	void registrarPersona(Persona persona);
    void registrarMedio(Medio medio);
    void realizarCompra(Persona vendedor, String codigoQR, Pagadora medioPagador) throws SaldoInsuficienteException, ExcedeLimiteDeCompraException;
    void realizarTransferencia(Transferible origen, Transferible destino, double monto) throws SaldoInsuficienteException;
}