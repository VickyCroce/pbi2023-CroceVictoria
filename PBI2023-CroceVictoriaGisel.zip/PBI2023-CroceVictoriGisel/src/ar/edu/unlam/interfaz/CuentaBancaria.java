package ar.edu.unlam.interfaz;

public class CuentaBancaria implements Medio, Transferible{
	 private String cbu;
	    private double saldo;

	    public CuentaBancaria(String cbu, double saldo) {
	        this.cbu = cbu;
	        this.saldo = saldo;
	    }

		@Override
		public String getIdentificador() {
			// TODO Auto-generated method stub
			return cbu;
		}

		@Override
		public Double getSaldo() {
			// TODO Auto-generated method stub
			return saldo;
		}

		@Override
		public void depositar(Double importe) throws SaldoInsuficienteException {
			// TODO Auto-generated method stub
			if(getSaldo() < importe) {
				throw new SaldoInsuficienteException();
			}else {
				importe -= getSaldo();
			}
			
		}

		@Override
		public Boolean extraer(Double importe) throws SaldoInsuficienteException {
			// TODO Auto-generated method stub
			if(getSaldo() < importe) {
				throw new SaldoInsuficienteException();			
				}
			else {
				importe -= getSaldo();
			}
			return null;
			
		}

	
	
	

}
