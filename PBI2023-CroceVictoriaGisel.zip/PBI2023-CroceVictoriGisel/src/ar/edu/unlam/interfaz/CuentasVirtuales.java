package ar.edu.unlam.interfaz;

public class CuentasVirtuales implements Medio, Transferible{
	 private String cvu;
	 private double saldo;

	    public CuentasVirtuales(String cvu, double saldo) {
	        this.cvu = cvu;
	        this.saldo = saldo;
	    }
	@Override
	public String getIdentificador() {
		// TODO Auto-generated method stub
		return cvu;
	}
	@Override
	public Double getSaldo() {
		// TODO Auto-generated method stub
		return saldo;
	}
	@Override
	public void depositar(Double importe) throws SaldoInsuficienteException {
		// TODO Auto-generated method stub
		if(getSaldo() < importe) {
			throw new SaldoInsuficienteException();
		}else {
			importe -= getSaldo();
		}
		
	}

	@Override
	public Boolean extraer(Double importe) throws SaldoInsuficienteException {
		// TODO Auto-generated method stub
		if(getSaldo() < importe) {
			throw new SaldoInsuficienteException();			
			}
		else {
			importe -= getSaldo();
		}
		return null;
		
	}

}
