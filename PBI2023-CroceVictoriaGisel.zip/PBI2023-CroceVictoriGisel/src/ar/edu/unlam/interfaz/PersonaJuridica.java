package ar.edu.unlam.interfaz;

import java.util.*;

public class PersonaJuridica implements Persona, Comparable<PersonaJuridica> {
	private String nombre;
	private String cuit;
	private List<Persona> personas;

	public PersonaJuridica(String nombre, String cuit) {
		super();
		this.nombre = nombre;
		this.cuit = cuit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCuit() {
		return cuit;
	}

	public void setCuit(String cuit) {
		this.cuit = cuit;
	}

	@Override
	public String getIdentificador() {
		return cuit;
	}

	@Override
	public int compareTo(PersonaJuridica otraPersona) {
		return this.cuit.compareTo(otraPersona.getIdentificador());
	}

}
