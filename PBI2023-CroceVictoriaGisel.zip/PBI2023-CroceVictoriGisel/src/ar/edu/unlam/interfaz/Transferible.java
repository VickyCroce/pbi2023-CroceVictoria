package ar.edu.unlam.interfaz;

public  interface Transferible {
	Double getSaldo();
	void depositar(Double importe) throws SaldoInsuficienteException;
	Boolean extraer (Double importe) throws SaldoInsuficienteException;
}
